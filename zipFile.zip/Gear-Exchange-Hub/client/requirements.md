## Packages
framer-motion | Page transitions and animations
lucide-react | Iconography
date-fns | Date formatting

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
}
